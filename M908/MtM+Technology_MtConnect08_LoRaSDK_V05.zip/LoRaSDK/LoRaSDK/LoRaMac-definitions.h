/*
 / _____)             _              | |
( (____  _____ ____ _| |_ _____  ____| |__
 \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 _____) ) ____| | | || |_| ____( (___| | | |
(______/|_____)_|_|_| \__)_____)\____)_| |_|
    (C)2013 Semtech

Description: LoRa MAC layer global definitions

License: Revised BSD License, see LICENSE.TXT file include in the project

Maintainer: Miguel Luis and Gregory Cristian
*/
#include "radio.h"
#include "qm_common.h"
#ifndef __LORAMAC_BOARD_H__
#define __LORAMAC_BOARD_H__

/*!
 * Returns individual channel mask
 *
 * \param[IN] channelIndex Channel index 1 based
 * \retval channelMask
 */
#define LC( channelIndex )            ( uint16_t )( 1 << ( channelIndex - 1 ) )

/*!
 * LoRaMac duty cycle for the back-off procedure
 */
#define BACKOFF_DC_1_HOUR       100
#define BACKOFF_DC_10_HOURS     1000
#define BACKOFF_DC_24_HOURS     10000

#define BACKOFF_RND_OFFSET      600000

/*!
 * LoRaMac EU868 default bands
 */
typedef enum
{
    BAND_G1_0,
    BAND_G1_1,
    BAND_G1_2,
    BAND_G1_3,
    BAND_G1_4,
}BandId_t;

/*!
 * LoRaMac datarates definition
 */					   // Band 915	               // Band 433,Band780,Band868
#define DR_0		0  // SF10 - BW125 |			; SF12 - BW125
#define DR_1       	1  // SF9  - BW125 |			; SF11 - BW125
#define DR_2        2  // SF8  - BW125 +-> Up link	; SF10 - BW125
#define DR_3        3  // SF7  - BW125 |			; SF9  - BW125
#define DR_4        4  // SF8  - BW500 |			; SF8  - BW125
#define DR_5        5  // RFU						; SF7  - BW125
#define DR_6        6  // RFU						; SF7  - BW250
#define DR_7        7  // RFU						; FSK
#define DR_8        8  // SF12 - BW500 |
#define DR_9        9  // SF11 - BW500 |
#define DR_10       10 // SF10 - BW500 |
#define DR_11       11 // SF9  - BW500 |
#define DR_12       12 // SF8  - BW500 +-> Down link;
#define DR_13       13 // SF7  - BW500 |
#define DR_14       14 // RFU          |
#define DR_15       15 // RFU          |


/*!
 * LoRaMac default channels
 */
// Channel = { Frequency [Hz], { ( ( DrMax << 4 ) | DrMin ) }, Band }
/*
 * US band channels are initialized using a loop in LoRaMacInit function
 * \code
 * // 125 kHz channels
 * for( uint8_t i = 0; i < LORA_MAX_NB_CHANNELS - 8; i++ )
 * {
 *     Channels[i].Frequency = 902.3e6 + i * 200e3;
 *     Channels[i].DrRange.Value = ( DR_3 << 4 ) | DR_0;
 *     Channels[i].Band = 0;
 * }
 * // 500 kHz channels
 * for( uint8_t i = LORA_MAX_NB_CHANNELS - 8; i < LORA_MAX_NB_CHANNELS; i++ )
 * {
 *     Channels[i].Frequency = 903.0e6 + ( i - ( LORA_MAX_NB_CHANNELS - 8 ) ) * 1.6e6;
 *     Channels[i].DrRange.Value = ( DR_4 << 4 ) | DR_4;
 *     Channels[i].Band = 0;
 * }
 * \endcode
 */

#endif // __LORAMAC_BOARD_H__
