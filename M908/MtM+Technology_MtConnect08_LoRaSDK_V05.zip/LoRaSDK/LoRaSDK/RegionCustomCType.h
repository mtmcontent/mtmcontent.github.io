/*!
 * \file      RegionCustomCType.h
 *
 * \brief     Region definition for CustomCType
 *
 * \copyright Revised BSD License, see section \ref LICENSE.
 *
 * \code
 *                ______                              _
 *               / _____)             _              | |
 *              ( (____  _____ ____ _| |_ _____  ____| |__
 *               \____ \| ___ |    (_   _) ___ |/ ___)  _ \
 *               _____) ) ____| | | || |_| ____( (___| | | |
 *              (______/|_____)_|_|_| \__)_____)\____)_| |_|
 *              (C)2013 Semtech
 *
 *               ___ _____ _   ___ _  _____ ___  ___  ___ ___
 *              / __|_   _/_\ / __| |/ / __/ _ \| _ \/ __| __|
 *              \__ \ | |/ _ \ (__| ' <| _| (_) |   / (__| _|
 *              |___/ |_/_/ \_\___|_|\_\_| \___/|_|_\\___|___|
 *              embedded.connectivity.solutions===============
 *
 * \endcode
 *
 * \author    Miguel Luis ( Semtech )
 *
 * \author    Gregory Cristian ( Semtech )
 *
 * \author    Daniel Jaeckle ( STACKFORCE )
 *
 * \defgroup  REGIONCustomCType Region base from AS923
 *            Implementation according to LoRaWAN Specification v1.0.2.
 * \{
 */
#ifndef __REGION_CustomCType_H__
#define __REGION_CustomCType_H__
#include "LoRaMac.h"
#include "Region.h"
#include "RegionCommon.h"
#include "qm_common.h"

/*!
 * LoRaMac maximum number of channels
 */
#define CustomCType_MAX_NB_CHANNELS_def                       16

/*!
 * Number of default channels
 */
#define CustomCType_NUMB_DEFAULT_CHANNELS_def                 2


/*!
 * Minimal datarate that can be used by the node
 */
#define CustomCType_TX_MIN_DATARATE                       DR_0

/*!
 * Maximal datarate that can be used by the node
 */
#define CustomCType_TX_MAX_DATARATE_def                   DR_7

/*!
 * Minimal datarate that can be used by the node
 */
#define CustomCType_RX_MIN_DATARATE                       DR_0

/*!
 * Maximal datarate that can be used by the node
 */
#define CustomCType_RX_MAX_DATARATE_def                    DR_7

/*!
 * Default datarate used by the node
 */
#define CustomCType_DEFAULT_DATARATE                      DR_0

/*!
 * Minimal Rx1 receive datarate offset
 */
#define CustomCType_MIN_RX1_DR_OFFSET                     0

/*!
 * Maximal Rx1 receive datarate offset
 */
#define CustomCType_MAX_RX1_DR_OFFSET_def                     7

/*!
 * Default Rx1 receive datarate offset
 */
#define CustomCType_DEFAULT_RX1_DR_OFFSET                 0

/*!
 * Minimal Tx output power that can be used by the node
 */
#define CustomCType_MIN_TX_POWER_def                          TX_POWER_5

/*!
 * Maximal Tx output power that can be used by the node
 */
#define CustomCType_MAX_TX_POWER_def                          TX_POWER_0

/*!
 * Default Tx output power used by the node
 */
#define CustomCType_DEFAULT_TX_POWER_def                      TX_POWER_0

/*!
 * Default uplink dwell time configuration
 */
#define CustomCType_DEFAULT_UPLINK_DWELL_TIME             0

/*!
 * Default downlink dwell time configuration
 */
#define CustomCType_DEFAULT_DOWNLINK_DWELL_TIME           0

/*!
 * Default Max EIRP
 */
#define CustomCType_DEFAULT_MAX_EIRP                      14

/*!
 * ADR Ack limit
 */
#define CustomCType_ADR_ACK_LIMIT                         64

/*!
 * ADR Ack delay
 */
#define CustomCType_ADR_ACK_DELAY                         32

/*!
 * Enabled or disabled the duty cycle
 */
#define CustomCType_DUTY_CYCLE_ENABLED                    0

/*!
 * Maximum RX window duration
 */
#define CustomCType_MAX_RX_WINDOW                         3000

/*!
 * Receive delay 1
 */
#define CustomCType_RECEIVE_DELAY1                        1000

/*!
 * Receive delay 2
 */
#define CustomCType_RECEIVE_DELAY2                        2000

/*!
 * Join accept delay 1
 */
#define CustomCType_JOIN_ACCEPT_DELAY1                    5000

/*!
 * Join accept delay 2
 */
#define CustomCType_JOIN_ACCEPT_DELAY2                    6000

/*!
 * Maximum frame counter gap
 */
#define CustomCType_MAX_FCNT_GAP                          16384

/*!
 * Ack timeout
 */
#define CustomCType_ACKTIMEOUT                            2000

/*!
 * Random ack timeout limits
 */
#define CustomCType_ACK_TIMEOUT_RND                       1000

#if ( CustomCType_DEFAULT_DATARATE > DR_5 )
#error "A default DR higher than DR_5 may lead to connectivity loss."
#endif

/*!
 * Second reception window channel frequency definition.
 */
#define CustomCType_RX_WND_2_FREQ_def                         923200000

/*!
 * Second reception window channel datarate definition.
 */
#define CustomCType_RX_WND_2_DR_def                           DR_2

/*!
 * Maximum number of bands
 */
#define CustomCType_MAX_NB_BANDS                          1

/*!
 * Band 0 definition
 * { DutyCycle, TxMaxPower, LastTxDoneTime, TimeOff }
 */
#define CustomCType_BAND0                                 { 100, CustomCType_DEFAULT_TX_POWER_def, 0,  0 } //  1.0 %
#define KR920_BAND0                                       { 1, TX_POWER_1, 0,  0 }

/*!
 * LoRaMac default channel 1
 * Channel = { Frequency [Hz], RX1 Frequency [Hz], { ( ( DrMax << 4 ) | DrMin ) }, Band }
 */
#define CustomCType_LC1                                   { 923200000, 0, { ( ( DR_5 << 4 ) | DR_0 ) }, 0 }
#define KR920_LC1                                   { 922100000, 0, { ( ( DR_5 << 4 ) | DR_0 ) }, 0 }

/*!
 * LoRaMac default channel 2
 * Channel = { Frequency [Hz], RX1 Frequency [Hz], { ( ( DrMax << 4 ) | DrMin ) }, Band }
 */
#define CustomCType_LC2                                   { 923400000, 0, { ( ( DR_5 << 4 ) | DR_0 ) }, 0 }
#define KR920_LC2                                   { 922300000, 0, { ( ( DR_5 << 4 ) | DR_0 ) }, 0 }

/*!
 * LoRaMac default channel 3
 * Channel = { Frequency [Hz], RX1 Frequency [Hz], { ( ( DrMax << 4 ) | DrMin ) }, Band }
 */
#define KR920_LC3                                   { 922500000, 0, { ( ( DR_5 << 4 ) | DR_0 ) }, 0 }

/*!
 * LoRaMac channels which are allowed for the join procedure
 */
#define CustomCType_JOIN_CHANNELS                         ( uint16_t )( LC( 1 ) | LC( 2 ) )
#define KR920_JOIN_CHANNELS                         ( uint16_t )( LC( 1 ) | LC( 2 ) | LC( 3 ) )

/*!
 * RSSI threshold for a free channel [dBm]
 */
#define CustomCType_RSSI_FREE_TH_def                          -85

/*!
 * Specifies the time the node performs a carrier sense
 */
#define CustomCType_CARRIER_SENSE_TIME                    6

/*!
 * Data rates table definition
 */
static const uint8_t DataratesCustomCType[]  = { 12, 11, 10,  9,  8,  7, 7, 50 };

/*!
 * Maximum payload with respect to the datarate index. Cannot operate with repeater.
 * The table is valid for the dwell time configuration of 0 for uplinks and downlinks.
 */
static const uint8_t MaxPayloadOfDatarateDwell0CustomCType[] = { 51, 51, 51, 115, 242, 242, 242, 242 };
static const uint8_t MaxPayloadOfDatarateKR920[] = { 65, 151, 242, 242, 242, 242 };


/*!
 * Maximum payload with respect to the datarate index. Can operate with repeater.
 * The table is valid for the dwell time configuration of 0 for uplinks and downlinks. The table provides
 * repeater support.
 */
static const uint8_t MaxPayloadOfDatarateRepeaterDwell0CustomCType[] = { 51, 51, 51, 115, 222, 222, 222, 222 };

/*!
 * Maximum payload with respect to the datarate index. Can operate with and without repeater.
 * The table proides repeater support. The table is only valid for uplinks.
 */
static const uint8_t MaxPayloadOfDatarateDwell1UpCustomCType[] = { 0, 0, 11, 53, 125, 242, 242, 242 };

/*!
 * Maximum payload with respect to the datarate index. Can operate with and without repeater.
 * The table proides repeater support. The table is only valid for downlinks.
 */
static const uint8_t MaxPayloadOfDatarateDwell1DownCustomCType[] = { 0, 0, 11, 53, 126, 242, 242, 242 };

/*!
 * Effective datarate offsets for receive window 1.
 */
static const int8_t EffectiveRx1DrOffsetCustomCType[] = { 0, 1, 2, 3, 4, 5, -1, -2 };

/*!
 * Tx output powers table definition
 */
static const int8_t TxPowersKR920[] = { 20, 14, 10,  8,  5,  2, 0 };



/*!
 * \brief The function gets a value of a specific phy attribute.
 *
 * \param [IN] getPhy Pointer to the function parameters.
 */
void RegionCustomCTypeGetPhyParam( GetPhyParams_t* getPhy );

/*!
 * \brief Updates the last TX done parameters of the current channel.
 *
 * \param [IN] txDone Pointer to the function parameters.
 */
void RegionCustomCTypeSetBandTxDone( SetBandTxDoneParams_t* txDone );

/*!
 * \brief Initializes the channels masks and the channels.
 *
 * \param [IN] type Sets the initialization type.
 */
void RegionCustomCTypeInitDefaults( InitType_t type );

/*!
 * \brief Verifies a parameter.
 *
 * \param [IN] verify Pointer to the function parameters.
 *
 * \param [IN] type Sets the initialization type.
 *
 * \retval Returns true, if the parameter is valid.
 */
bool RegionCustomCTypeVerify( VerifyParams_t* verify, PhyAttribute_t phyAttribute );

/*!
 * \brief The function parses the input buffer and sets up the channels of the
 *        CF list.
 *
 * \param [IN] applyCFList Pointer to the function parameters.
 */
void RegionCustomCTypeApplyCFList( ApplyCFListParams_t* applyCFList );

/*!
 * \brief Sets a channels mask.
 *
 * \param [IN] chanMaskSet Pointer to the function parameters.
 *
 * \retval Returns true, if the channels mask could be set.
 */
bool RegionCustomCTypeChanMaskSet( ChanMaskSetParams_t* chanMaskSet );

/*!
 * \brief Calculates the next datarate to set, when ADR is on or off.
 *
 * \param [IN] adrNext Pointer to the function parameters.
 *
 * \param [OUT] drOut The calculated datarate for the next TX.
 *
 * \param [OUT] txPowOut The TX power for the next TX.
 *
 * \param [OUT] adrAckCounter The calculated ADR acknowledgement counter.
 *
 * \retval Returns true, if an ADR request should be performed.
 */
bool RegionCustomCTypeAdrNext( AdrNextParams_t* adrNext, int8_t* drOut, int8_t* txPowOut, uint32_t* adrAckCounter );

/*!
 * \brief Configuration of the RX windows.
 *
 * \param [IN] rxConfig Pointer to the function parameters.
 *
 * \param [OUT] datarate The datarate index which was set.
 *
 * \retval Returns true, if the configuration was applied successfully.
 */
bool RegionCustomCTypeRxConfig( RxConfigParams_t* rxConfig, int8_t* datarate );

/*!
 * \brief TX configuration.
 *
 * \param [IN] txConfig Pointer to the function parameters.
 *
 * \param [OUT] txPower The tx power index which was set.
 *
 * \param [OUT] txTimeOnAir The time-on-air of the frame.
 *
 * \retval Returns true, if the configuration was applied successfully.
 */
bool RegionCustomCTypeTxConfig( TxConfigParams_t* txConfig, int8_t* txPower, uint32_t* txTimeOnAir );

/*!
 * \brief The function processes a Link ADR Request.
 *
 * \param [IN] linkAdrReq Pointer to the function parameters.
 *
 * \retval Returns the status of the operation, according to the LoRaMAC specification.
 */
uint8_t RegionCustomCTypeLinkAdrReq( LinkAdrReqParams_t* linkAdrReq, int8_t* drOut, int8_t* txPowOut, uint8_t* nbRepOut, uint8_t* nbBytesParsed );

/*!
 * \brief The function processes a RX Parameter Setup Request.
 *
 * \param [IN] rxParamSetupReq Pointer to the function parameters.
 *
 * \retval Returns the status of the operation, according to the LoRaMAC specification.
 */
uint8_t RegionCustomCTypeRxParamSetupReq( RxParamSetupReqParams_t* rxParamSetupReq );

/*!
 * \brief The function processes a Channel Request.
 *
 * \param [IN] newChannelReq Pointer to the function parameters.
 *
 * \retval Returns the status of the operation, according to the LoRaMAC specification.
 */
uint8_t RegionCustomCTypeNewChannelReq( NewChannelReqParams_t* newChannelReq );

/*!
 * \brief The function processes a TX ParamSetup Request.
 *
 * \param [IN] txParamSetupReq Pointer to the function parameters.
 *
 * \retval Returns the status of the operation, according to the LoRaMAC specification.
 *         Returns -1, if the functionality is not implemented. In this case, the end node
 *         shall not process the command.
 */
int8_t RegionCustomCTypeTxParamSetupReq( TxParamSetupReqParams_t* txParamSetupReq );

/*!
 * \brief The function processes a DlChannel Request.
 *
 * \param [IN] dlChannelReq Pointer to the function parameters.
 *
 * \retval Returns the status of the operation, according to the LoRaMAC specification.
 */
uint8_t RegionCustomCTypeDlChannelReq( DlChannelReqParams_t* dlChannelReq );

/*
 * \brief Alternates the datarate of the channel for the join request.
 *
 * \param [IN] alternateDr Pointer to the function parameters.
 *
 * \retval Datarate to apply.
 */
int8_t RegionCustomCTypeAlternateDr( AlternateDrParams_t* alternateDr );

/*!
 * \brief Calculates the back-off time.
 *
 * \param [IN] calcBackOff Pointer to the function parameters.
 */
void RegionCustomCTypeCalcBackOff( CalcBackOffParams_t* calcBackOff );

/*!
 * \brief Searches and set the next random available channel
 *
 * \param [OUT] channel Next channel to use for TX.
 *
 * \param [OUT] time Time to wait for the next transmission according to the duty
 *              cycle.
 *
 * \retval Function status [1: OK, 0: Unable to find a channel on the current datarate]
 */
bool RegionCustomCTypeNextChannel( NextChanParams_t* nextChanParams, uint8_t* channel, uint32_t* time );

/*!
 * \brief Adds a channel.
 *
 * \param [IN] channelAdd Pointer to the function parameters.
 *
 * \retval Status of the operation.
 */
LoRaMacStatus_t RegionCustomCTypeChannelAdd( ChannelAddParams_t* channelAdd );

/*!
 * \brief Removes a channel.
 *
 * \param [IN] channelRemove Pointer to the function parameters.
 *
 * \retval Returns true, if the channel was removed successfully.
 */
bool RegionCustomCTypeChannelsRemove( ChannelRemoveParams_t* channelRemove  );

/*!
 * \brief Sets the radio into continuous wave mode.
 *
 * \param [IN] continuousWave Pointer to the function parameters.
 */
void RegionCustomCTypeSetContinuousWave( ContinuousWaveParams_t* continuousWave );

void RegionCustomCTypeSetPreambleLength( uint8_t CustomPreambleLength );

void RegionCustomCTypeSetCustomMaxChannel( uint8_t CustomMaxChannel );

void RegionCustomCTypeSetNBOfChannels( uint8_t NumbChannels);

void RegionCustomCTypeSetRX2WindowFreq( uint32_t Frequency );

void RegionCustomCSetRegion( LoRaMacRegion_t region);

void RegionCustomCTypeTXPowerParams(uint8_t MinTxPower, uint8_t MaxTxPower, uint8_t DefaultTxPower );

/*! \} defgroup REGIONCustomCType */

#endif // __REGION_CustomCType_H__
